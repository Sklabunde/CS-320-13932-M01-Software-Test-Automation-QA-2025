package contact;

import java.util.HashMap;
import java.util.Map;


public class ContactService {
	public Map<String, Contact> contacts; //Map to store contact.
	
	public ContactService() {
		contacts = new HashMap<>();
	}
	
	public void addContact(Contact contact) { //Create method to add Contact
		contacts.put(contact.getContactID(), contact);
	}
	public void deleteContact(String contactID) { //Create method to delete Contact
		contacts.remove(contactID);
	}
	public void updateFirstName(String contactID, String newFirstName) { //Create method to update variables
		Contact contact = contacts.get(contactID);
		if (contact != null) {
			contact.firstName = newFirstName;
		}
	}
	public void updateLastName(String contactID, String newLastName) {
		Contact contact = contacts.get(contactID);
		if (contact != null) {
			contact.lastName = newLastName;
		}
	}
	public void updateNumber(String contactID, String newNumber) {
		Contact contact = contacts.get(contactID);
		if (contact != null) {
			contact. number = newNumber;
		}
	}
	public void updateAddress(String contactID, String newAddress) {
		Contact contact = contacts.get(contactID);
		if (contact != null) {
			contact.address = newAddress;
		}
	}
	public Contact getContact(String contactID) { //Create method to locate contact
		return contacts.get(contactID);
	}
}
	
