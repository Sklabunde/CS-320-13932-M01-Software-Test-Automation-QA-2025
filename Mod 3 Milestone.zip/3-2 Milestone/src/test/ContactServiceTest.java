package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import contact.Contact;
import contact.ContactService;

class ContactServiceTest {

	@Test
	public void testAddContactID() { //Create method to test adding a contact 
		ContactService contactService = new ContactService();
		Contact contact = new Contact ("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contactService.addContact(contact);
		
		assertEquals(contact, contactService.getContact("1234567890").getContactID());
	}
	@Test
	public void testDeleteContact() { //Create method to deleting a contact.
		ContactService contactService = new ContactService();
		Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contactService.addContact(contact);
		contactService.deleteContact("1234567890");
		
		assertNull(contactService.getContact("1234567890"));
		
	}
	@Test
	public void testUpdateFirstName() { //Create methods for update to variables
		ContactService contactService = new ContactService();
		Contact contact = new Contact ("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contactService.addContact(contact);
		contactService.updateFirstName("1234567890", "Jessica");
		
		assertEquals("Jessica", contactService.getContact("1234567890").getFirstName());
	}
	@Test
	public void testUpdateLastName() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact ("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contactService.addContact(contact);
		contactService.updateLastName("1234567890", "Smith");
		
		assertEquals("Smith", contactService.getContact("1234567890").getLastName());
	}
	@Test
	public void testUpdateNumber() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact ("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contactService.addContact(contact);
		contactService.updateNumber("1234567890", "0987654321");
		
		assertEquals("0987654321", contactService.getContact("1234567890").getNumber());
	}
	@Test
	public void testUpdateAddress() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact ("1234567890", "John", "Doe", "1234567890", "123 Main St");
		contactService.addContact(contact);
		contactService.updateAddress("1234567890", "2933 Mayflower Rd");
		
		assertEquals("2933 Mayflower Rd", contactService.getContact("1234567890").getAddress());
	}

}
