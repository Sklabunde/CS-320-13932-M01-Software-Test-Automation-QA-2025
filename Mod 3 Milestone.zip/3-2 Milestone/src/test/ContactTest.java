package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import contact.Contact;

public class ContactTest {

	@Test
		public void testContactCreation() { //Create method to test contact creation
			Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
			
			assertNotNull(contact); //Create assertions for tests
			
			assertEquals("1234567890", contact.getContactID());
			assertEquals("John", contact.getFirstName());
			assertEquals("Doe", contact.getLastName());
			assertEquals("1234567890", contact.getNumber());
			assertEquals("123 Main St", contact.getAddress());
	}

}
