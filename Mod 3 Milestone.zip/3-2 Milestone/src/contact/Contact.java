/****
 * Steve Klabunde
 * CS-320
 * 07-18-2025
 * Contact Class, creates & stores users information
 */



package contact;

public class Contact { //Create contact class
	String contactID;
	String firstName;
	String lastName;
	String number;
	String address;
	
	
	
	public Contact (String contactID, String firstName, String lastName, String number, String address) { //Initialize variables
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.number = number;
		this.address = address;
		
		
		//Create conditions for Contact ID
		if (contactID == null || contactID.isEmpty()) {
			this.contactID = "NULL";
		}else if (contactID.length() > 10) {
			this.contactID = contactID.substring(0,10);
		}else {
			this.contactID = contactID;
		}
				
		
	//Create conditions for First Name
		if (firstName == null || firstName.isEmpty()) {
			this.firstName = "NULL";
		}else if (firstName.length() > 10) {
			this.firstName = firstName.substring(0,10);
		}else {
			this.firstName = firstName;
		}
		
	//Create conditions for Last Name
		if (lastName == null || lastName.isEmpty()) {
			this.lastName = "NULL";
		}else if (lastName.length() > 10) {
			this.lastName = lastName.substring(0,10);
		}else {
			this.lastName = lastName;
		}
	//Create conditions for Number
		if(number == null || number.isEmpty() || number.length() != 10) {
			this.number = "6666666666";
		}else {
			this.number = number;
		}
		
	//Create conditions for Address
		if(address == null || address.isEmpty()) {
			this.address = "NULL";
		}else if (address.length() > 30) {
			this.address = address.substring(0,30);
		}else {
			this.address = address;
		}
	}
	
	//Getters
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getNumber() {
		return number;
	}
	
	public String getAddress() {
		return address;
	}
	
	//Setters
	public void setContactID(String contactID) {
		if (contactID == null || contactID.isEmpty()) {
			this.contactID = "NULL";
		}else if (contactID.length() > 10) {
			this.contactID = contactID.substring(0, 10);
		}else {
			this.contactID = contactID;
		}
	}
	
	public void setFirstName(String firstName) {
		if (firstName == null || firstName.isEmpty()) {
			this.firstName = "NULL";
		}else if (firstName.length() > 10) {
			this.firstName = firstName.substring(0, 10);
		}else {
			this.firstName = firstName;
		}
	}
	
	public void setLastName(String lastName) {
		if (lastName == null || lastName.isEmpty()) {
			this.lastName = "NULL";
		}else if (lastName.length() > 10) {
			this.lastName = lastName.substring(0, 10);
		}else {
			this.lastName = lastName;
		}
	}
	
	public void setNumber(String number) {
		if (number == null || number.isEmpty() || number.length() != 10) {
			this.number = "6666666666";
		}else {
			this.number = number;
		}
	}
	
	public void setAddress(String address) {
		if (address == null || address.isEmpty()) {
			this.address = "NULL";
		}else if (address.length() >30) {
			this.address = address.substring(0,30);
		}
	}
}
